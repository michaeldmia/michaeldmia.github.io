A Pen created at CodePen.io. You can find this one at https://codepen.io/michaeldm/pen/eamWYa.

 jquery to add/remove class to change styles on element when scrolled past defined height. 
taken from http://jsfiddle.net/ult_combo/ayGwn/4/